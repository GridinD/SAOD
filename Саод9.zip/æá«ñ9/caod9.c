#include <stdio.h>
#include <stdlib.h>
#include <time.h>


int create_array(int n,int array[n]){
    for(int i = 0; i < n; i++){ 
        array[i]= rand()%10;  
    }
    return array[n];
}

void print_array(int n, int array[n]){
    for(int i = 0; i < n; i++){ 
        printf("%d  ", array[i]); 
    }
    printf("\n");
}
void line_find(int n, int key, int array[n]){
    int h = 0;
    for(int i = 0; i < n; i++){
        if (array[i] == key){
            array[h++] = i;
            //printf("Элемент равный %d под индесом %d\n", key, i); 
        }           
    }
    if (h != 0){
        for (int i = 0; i < h; i++){
            printf("Элемент равный %d под индесом %d\n", key, array[i]); 
        }
    }
    else{
        printf("Элементов равных %d нет\n", key); 
    }

}

int binarysearch(int key, int array[], int n){
    int low, high, middle;
    low = 0;
    high = n - 1;
    while (low <= high)
    {
        middle = (low + high) / 2;
        if (key < array[middle])
            high = middle - 1;
        else if (key > array[middle])
            low = middle + 1;
        else 
            return middle;
    }
    return -1;
}   
int inclusionSort(int array[], int n)
{

    for (int i = 1; i < n; i++)
    {
        int value = array[i];
        int index = i;

        while ((index > 0) && (array[index - 1] > value))
        {
            array[index] = array[index - 1];
            index--;
        }
        array[index] = value;
    }
    return array[n];
}        


int main(){
    int n, key, point, point1;
    printf("Введите размер массива:\n");
    scanf("%d", &n);
    int array[n];
    int index[n];
    srand(time(NULL));
    create_array(n, array);
    print_array(n, array);
    scanf("%d", &key);
    line_find(n,key,array);
    
    inclusionSort(array, n);
    print_array(n, array);
    point = binarysearch(key, array, n);
    if (point != -1){
        printf("Элемент равный %d под индесом %d\n", key, point); 
    }
    else {
         printf("Таких элементов нет\n"); 
    }
    
  }


