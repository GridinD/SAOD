#include <stdio.h> 
#include <string.h>
#include <locale.h>
#include <windows.h>
 
char* userStrstr(const char* haystack, char* needle)
{
    for (const char* hp = haystack; hp != haystack + strlen(haystack); ++hp)
    {
        const char* np = needle;
        const char* tmp = hp;
        for ( ; np != needle + strlen(needle); ++np){
            if (*tmp != *np){
                break;
            }
            else{
                ++tmp;
            }
        }
        if (np == needle + strlen(needle))
        {
            return needle;
        }
    }
    return 0;
}

int main()
{
    setlocale(LC_CTYPE, "rus");
    char first[] = "Сложнее всего начать действовать, все остальное зависит только от упорства.";
    char second[] = "начать";

    if (userStrstr(first, second) == second)
    {
        printf("Такое слово есть: %s\n", second);
    }
    if (userStrstr(first, second) == 0)
    {
        printf("Такого слова нет\n");
    }
}