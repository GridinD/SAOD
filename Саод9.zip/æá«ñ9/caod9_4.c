#include <stdio.h> 
#include <string.h>
 
int KMPSearch(char *string, char *substring){
  int  sl, ssl;
  int res = -1;
  sl = strlen(string);
  ssl = strlen(substring);
  if ( sl == 0 ) 
    printf("Неверно задана строка\n"); 
  else if ( ssl == 0 ) 
    printf("Неверно задана подстрока\n"); 
  else {
    int  i, j = 0, k = -1;
    int  d[1000];
    d[0] = -1;
    while ( j < ssl - 1 ) {
      while ( k >= 0 && substring[j] != substring[k] ) 
        k = d[k];
      j++;
      k++;
      if ( substring[j] == substring[k] )
        d[j] = d[k];
      else 
        d[j] = k;
    }
    i = 0;
    j = 0;
    while ( j < ssl && i < sl ){
      while ( j >= 0 && string[i] != substring[j] )
        j = d[j];
      i++;
      j++;
    }
   if (j == ssl){
       res = i - ssl;
   }
   else res = -1;
  }
  return res;
}

int main(){
    char first[] = "Сложнее всего начать действовать, все остальное зависит только от упорства.";
    char second[] = "остальное";
    int point;
    point = KMPSearch(first, second);

    if (point == -1){
        printf("Такого слова нет\n");
    }
    else{
        printf("Такое слово есть: %s\nИндекс:%d\n", second, point);
    }
    
}
